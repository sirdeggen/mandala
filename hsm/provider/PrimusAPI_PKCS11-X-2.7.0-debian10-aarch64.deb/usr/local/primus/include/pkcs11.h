/*
 * Copyright (c) Securosys SA 2016-2026.  All Rights Reserved.
 */

#ifndef _PRIMUS_PKCS11_H_
#define _PRIMUS_PKCS11_H_ 1

#if defined(__cplusplus)
extern "C" {
#endif

// --------------------------
// standard oasis-pkcs11-v3.2
// --------------------------

// platform specific macros
#if defined(_WIN32) || defined(CRYPTOKI_FORCE_WIN32)
#pragma pack(push, cryptoki, 1)
#ifdef CRYPTOKI_EXPORTS
#define CK_SPEC __declspec(dllexport)
#else
#define CK_SPEC __declspec(dllimport)
#endif
#else
#define CK_SPEC
#endif

// required macros
#define CK_PTR *
#define CK_DECLARE_FUNCTION(returnType, name) returnType CK_SPEC name
#define CK_DECLARE_FUNCTION_POINTER(returnType, name) returnType CK_SPEC (* name)
#define CK_CALLBACK_FUNCTION(returnType, name) returnType (* name)
#ifndef NULL_PTR
#if defined(__cplusplus)
#define NULL_PTR nullptr
#else
#define NULL_PTR 0
#endif
#endif

// add workarounds for errors in CK_HKDF_PARAMS
#define CK_BOOL CK_BBOOL
#define CK_HANDLE CK_OBJECT_HANDLE

// include the original "oasis-pkcs11-v3.2" header file
#include "oasis-pkcs11-v3.2/pkcs11.h"

// add missing MGFs
#define CKG_MGF1_SHA3_224                      0x00000006UL
#define CKG_MGF1_SHA3_256                      0x00000007UL
#define CKG_MGF1_SHA3_384                      0x00000008UL
#define CKG_MGF1_SHA3_512                      0x00000009UL

// add omitted typedefs
typedef CK_KEY_TYPE CK_PTR CK_KEY_TYPE_PTR;

// -----------------------------
// vendor specific primus-pkcs11
// -----------------------------

// flag values 'CK_FLAGS'
#define CKF_CONNECT_ON_INIT                    (1UL << 29)
#define CKF_NO_CONNECT_ON_INIT                 (1UL << 30)
#define CKF_INITIALIZE_COUNTING                (1UL << 31)

// key types 'CK_KEY_TYPE'
#define CKK_EC_SLIP10                          0x80000014UL
#define CKK_EC_EDWARDS_SLIP10                  0x80000015UL

// mechanism types 'CK_MECHANISM_TYPE'
#define CKM_KDF_CTR_CMAC_AES                   0x80000001UL
#define CKM_KDF_CTR_HMAC_SHA1                  0x80000002UL
#define CKM_KDF_CTR_HMAC_SHA224                0x80000003UL
#define CKM_KDF_CTR_HMAC_SHA256                0x80000004UL
#define CKM_KDF_CTR_HMAC_SHA384                0x80000005UL
#define CKM_KDF_CTR_HMAC_SHA512                0x80000006UL
#define CKM_KDF_FEEDBACK_CMAC_AES              0x80000007UL
#define CKM_KDF_FEEDBACK_HMAC_SHA1             0x80000008UL
#define CKM_KDF_FEEDBACK_HMAC_SHA224           0x80000009UL
#define CKM_KDF_FEEDBACK_HMAC_SHA256           0x8000000AUL
#define CKM_KDF_FEEDBACK_HMAC_SHA384           0x8000000BUL
#define CKM_KDF_FEEDBACK_HMAC_SHA512           0x8000000CUL
#define CKM_KDF_PIPELINE_CMAC_AES              0x8000000DUL
#define CKM_KDF_PIPELINE_HMAC_SHA1             0x8000000EUL
#define CKM_KDF_PIPELINE_HMAC_SHA224           0x8000000FUL
#define CKM_KDF_PIPELINE_HMAC_SHA256           0x80000010UL
#define CKM_KDF_PIPELINE_HMAC_SHA384           0x80000011UL
#define CKM_KDF_PIPELINE_HMAC_SHA512           0x80000012UL
#define CKM_KEY_SPLIT                          0x80000018UL
#define CKM_ECIES                              0x80001055UL

// SKA mechanisms for key generation
#define CKM_SKA_RSA_PKCS_KEY_PAIR_GEN          0x80002100UL
#define CKM_SKA_DSA_KEY_PAIR_GEN               0x80002101UL
#define CKM_SKA_EC_KEY_PAIR_GEN                0x80002102UL
#define CKM_SKA_EC_EDWARDS_KEY_PAIR_GEN        0x80002103UL
#define CKM_SKA_EC_SLIP10_KEY_PAIR_GEN         0x80002104UL
#define CKM_SKA_EC_SLIP10_EDWARDS_KEY_PAIR_GEN 0x80002105UL

#define CKM_RKS_RSA_PKCS_KEY_PAIR_GEN          0x80002200UL
#define CKM_RKS_EC_KEY_PAIR_GEN                0x80002201UL

// SLIP10 mechanisms
#define CKM_SLIP10_CHILD_DERIVE                0x80000E01UL
#define CKM_EC_SLIP10_KEY_PAIR_GEN             0x80000E02UL
#define CKM_EC_EDWARDS_SLIP10_KEY_PAIR_GEN     0x80000E03UL

// SLIP10 attributes
#define CKA_SLIP10_CHAIN_CODE                  0x80001100UL

// SKA attributes for `CK_ATTRIBUTE`
#define CKA_SKA_BLOCKED                        0x80000001UL // Whether private SKA key is blocked. Default false.
#define CKA_SKA_SENSITIVE_PUBLIC_KEY           0x80000002UL // When true: public key not extractable. Motivated by concern of computing private key from public key using quantum computers. Default false. Stored in private key attributes.
#define CKA_SKA_CRYPTO_CURRENCY_TYPE           0x80000003UL // Specifies crypto currency for which private key is used.
#define CKA_SKA_TIMESTAMP_SIGN                 0x80000004UL

// SKA policy attributes for `CK_ATTRIBUTE`
#define CKA_SKA_USAGE_ACCESS_BLOB              0x80000011UL 
#define CKA_SKA_BLOCK_ACCESS_BLOB              0x80000012UL
#define CKA_SKA_UNBLOCK_ACCESS_BLOB            0x80000013UL
#define CKA_SKA_MODIFY_ACCESS_BLOB             0x80000014UL

#define CKA_RKS_TIMESTAMP_SIGN                 0x80000020UL
#define CKA_RKS_ATTESTATION_SIGN               0x80000021UL
#define CKA_RKS_CERTIFICATE_CHAIN              0x80000022UL

// object class for `CK_OBJECT_CLASS` 
#define CKO_SECUROSYS_USER_CREDENTIALS        (CKO_VENDOR_DEFINED+1) // Unused.
#define CKO_SECUROSYS_NOT_SPECIFIED           (CKO_VENDOR_DEFINED+2) // Unused.
#define CKO_SKA_PRIVATE_KEY                   (CKO_VENDOR_DEFINED+3)
#define CKO_RKS_PRIVATE_KEY                   (CKO_VENDOR_DEFINED+4) // Root key store private key.

/* CK_CRYPTOCURRENCY is a value that identifies a cryptocurrency type */
typedef CK_ULONG                              CK_CRYPTOCURRENCY;

/* Cryptocurrency types */
#define CKCC_NOT_SPECIFIED                    0x00000000UL
#define CKCC_BITCOIN                          0x00000001UL
#define CKCC_ETHEREUM                         0x00000002UL
#define CKCC_STELLAR                          0x00000003UL
#define CKCC_IOTA                             0x00000004UL
#define CKCC_RIPPLE                           0x00000005UL
#define CKCC_CARDANO                          0x00000006UL

// CK_ECIES_PARAMS
typedef struct CK_ECIES_PARAMS {
    CK_BBOOL bLocalKdf;  // When true: Compute the KDF locally (requires that the ECDH result is extractable). When false: Compute the KDF on the HSM.
    CK_BBOOL bLocalDataEncryption; // Encrypt/decrypt payload data locally instead of on the HSM.
    CK_ULONG kdfMethod; // Method for the key derivation.
    CK_BYTE_PTR pKdfParameter; // Mechanism parameters for the KDF function.
    CK_ULONG ulKdfParameterLen; // Byte length of the supplied KDF parameter data.
    CK_ULONG cryptMethod; // Data encryption/decryption method.
    CK_ULONG ulCipherKeyLen; // Length of the cipher key in bytes.
    CK_ULONG macMethod; // Method for message authentication.
    CK_ULONG ulMacKeyLen; // Length of the MAC key in bytes.
    CK_ULONG ulMacTagLen; // Length of the MAC tag in bytes.
    CK_BYTE_PTR pSharedInfo1; // Pointer to shared info 1 data (flows into KDF).
    CK_ULONG ulSharedInfo1Len; // Length of shared secret 1.
    CK_BYTE_PTR pSharedInfo2; // Pointer to shared info 2 data.
    CK_ULONG ulSharedInfo2Len; // Length of shared secret 2 (flows into MAC tag).
    // Expert mode:
    CK_OBJECT_HANDLE hSenderPublicKey; // If the handle is non-zero then bypass the generation of an ephemeral key pair and use this public key instead. KNOW WHAT YOU DO!
    CK_OBJECT_HANDLE hSenderPrivateKey;  // If the handle is non-zero then bypass the generation of an ephemeral key pair and use this private key instead. KNOW WHAT YOU DO! (e.g. feed a nonce into sharedInfo1!)
    CK_BBOOL bSkipSenderPublicKeyOutput; // Disable the output of the public key in the ciphertext. For decryption requires that the sender public key is provided by hSenderPublicKey.
} CK_ECIES_PARAMS;
typedef CK_ECIES_PARAMS CK_PTR CK_ECIES_PARAMS_PTR;

// CK_SLIP10_CHILD_DERIVE_PARAMS
typedef struct CK_SLIP10_CHILD_DERIVE_PARAMS {
    CK_ULONG_PTR pulPathIndexes; // This shall be a vector of ULONG each representing a derivation level 
    CK_ULONG ulIndexCount; // Length of derivation vector
} CK_SLIP10_CHILD_DERIVE_PARAMS;
typedef CK_SLIP10_CHILD_DERIVE_PARAMS CK_PTR CK_SLIP10_CHILD_DERIVE_PARAMS_PTR;

// CK_HSM_STATUS
typedef struct CK_HSM_STATUS {
    CK_BYTE_PTR pHsmFirmwareVersionString;
    CK_ULONG ulHsmFirmwareVersionStringLen;
} CK_HSM_STATUS;
typedef CK_HSM_STATUS CK_PTR CK_HSM_STATUS_PTR;

// CK_HSM_SECRETS_FILE
typedef struct CK_HSM_SECRETS_FILE {
    CK_ULONG ulSize;
    CK_UTF8CHAR_PTR pData;
} CK_HSM_SECRETS_FILE;

/* CK_SKA_APPROVAL_TYPE is a value that identifies an approval type
 */
typedef CK_ULONG CK_SKA_APPROVAL_TYPE;
typedef CK_SKA_APPROVAL_TYPE CK_PTR CK_SKA_APPROVAL_TYPE_PTR;

#define CKAP_NOT_SPECIFIED              0x0UL
#define CKAP_SIGNATURE                  0x1UL
#define CKAP_CERTIFICATE                0x2UL

/* CK_SKA_APPROVAL is a structure that represents a signed approval
 */
typedef struct {
    // Type of the approval
    CK_SKA_APPROVAL_TYPE apType;
    // Signature of the approval
    CK_BYTE_PTR signatureData;
    CK_ULONG signatureSize;
    // Public key to check approval
    CK_BYTE_PTR publicKeyData;
    CK_ULONG publicKeySize;
} CK_SKA_APPROVAL; 
typedef CK_SKA_APPROVAL CK_PTR CK_SKA_APPROVAL_PTR;

/* CK_SKA_APPROVER is a structure that represents an approver identity/public key
 */
typedef struct {
    // Optional name of key owner, may not be set if approval type is certificate
    CK_CHAR_PTR pKeyOwnerNameData;
    CK_ULONG ulKeyOwnerNameLen;
    // Type of public key used to identity approver. Public key or certificate.
    // Specifies the type of approvals this approver can create.
    CK_SKA_APPROVAL_TYPE ulApType;
    CK_BYTE_PTR pKeydata;
    CK_ULONG ulLen;
} CK_SKA_APPROVER;
typedef CK_SKA_APPROVER CK_PTR CK_SKA_APPROVER_PTR;

/* CK_SKA_GROUP is a structure that represents a group of approvers that all
 * have to approve to enable SKA key usage
 */
typedef struct {
    // Optional name of group
    CK_CHAR_PTR pGroupNameData;
    CK_ULONG ulGroupNameLen;
    // Quorum required s.t. group gives approval
    CK_ULONG ulSignatureCount; // uint32_t over the wire
    CK_SKA_APPROVER_PTR pKeys;
    CK_ULONG ulKeyCount;
} CK_SKA_GROUP;
typedef CK_SKA_GROUP CK_PTR CK_SKA_GROUP_PTR;

/* CK_SKA_TOKEN is a structure that represents a group of groups that all
 * have to approve to enable SKA key usage
 */
typedef struct {
    // Optional name of token
    CK_CHAR_PTR pTokenNameData;
    CK_ULONG ulTokenNameLen;
    CK_ULONG ulDelaySeconds;
    CK_ULONG ulTimeLimitSeconds;
    CK_SKA_GROUP_PTR pGroups;
    CK_ULONG ulGroupCount;
} CK_SKA_TOKEN;
typedef CK_SKA_TOKEN CK_PTR CK_SKA_TOKEN_PTR;

/* CK_SKA_POLICY is a structure that represents tokens of which one
 * has to approve to enable SKA key usage
 */
typedef struct {
    CK_SKA_TOKEN_PTR pTokens;
    CK_ULONG ulTokenCount;
} CK_SKA_POLICY;
typedef CK_SKA_POLICY CK_PTR CK_SKA_POLICY_PTR;

/* CK_SKA_OPERATION is a value that identifies a usage of an SKA key
 */
typedef CK_ULONG CK_SKA_OPERATION;

#define CK_SKA_SIGN                     0x01UL
#define CK_SKA_BLOCK                    0x02UL
#define CK_SKA_UNBLOCK                  0x03UL
#define CK_SKA_MODIFY                   0x04UL
#define CK_SKA_DECRYPT                  0x05UL
#define CK_SKA_UNWRAP                   0x06UL

typedef struct CK_PRIMUS_FUNCTION_LIST CK_PRIMUS_FUNCTION_LIST;
typedef CK_PRIMUS_FUNCTION_LIST CK_PTR CK_PRIMUS_FUNCTION_LIST_PTR;
typedef CK_PRIMUS_FUNCTION_LIST CK_PTR CK_PTR CK_PRIMUS_FUNCTION_LIST_PTR_PTR;

#define _CK_DECLARE_FUNCTION(name, args) typedef CK_RV (*CK_ ## name) args; CK_RV CK_SPEC name args
_CK_DECLARE_FUNCTION(C_GetPrimusFunctionList, (CK_PRIMUS_FUNCTION_LIST_PTR_PTR primus_function_list));
_CK_DECLARE_FUNCTION(C_InitializeSpecificHSM, (void *init_args, const char* configurationFile, const char* secretsFile, const char* specificHSM, const char* specificUser));
_CK_DECLARE_FUNCTION(C_InitializeWithConfigFile, (void *init_args, const char* configurationFile, const char* secretsFile));
_CK_DECLARE_FUNCTION(C_InitializeOpenSSL, (const char* configurationFile));
_CK_DECLARE_FUNCTION(
    C_SetSecretsFileCallback,
    (const CK_HSM_SECRETS_FILE* (*secrets_file_generator)(),
     void (*secrets_file_deallocator)(const CK_HSM_SECRETS_FILE*)));
_CK_DECLARE_FUNCTION(C_GetUserChallenge, (
    CK_BYTE_PTR pUser,
    CK_ULONG ulUser,
    CK_BYTE_PTR pUserPass,
    CK_ULONG ulUserPass,
    CK_BYTE_PTR pPIN,
    CK_ULONG ulPIN,
    CK_BYTE_PTR pChallenge, 
    CK_ULONG_PTR pulChallengeLen));
_CK_DECLARE_FUNCTION(C_CryptoLogInit, (
    CK_SESSION_HANDLE hSession,
    CK_ULONG ulStartTime,
    CK_BBOOL bNewestFirst));
_CK_DECLARE_FUNCTION(C_CryptoLogFetch, (
    CK_SESSION_HANDLE hSession,
    CK_CHAR_PTR pBuffer,
    CK_ULONG_PTR pulBufferLen));
_CK_DECLARE_FUNCTION(C_CryptoLogFinal, (
    CK_SESSION_HANDLE hSession));
_CK_DECLARE_FUNCTION(C_HsmStatus, (
    CK_SLOT_ID ulSlotId,
    CK_HSM_STATUS_PTR pStatus));
_CK_DECLARE_FUNCTION(C_DeriveKeyPair, (
    CK_SESSION_HANDLE hSession,
    CK_MECHANISM_PTR pMechanism,
    CK_OBJECT_HANDLE hKey,
    CK_ATTRIBUTE_PTR pPublicKeyTemplate,
    CK_ULONG ulPublicKeyAttributeCount,
    CK_ATTRIBUTE_PTR pPrivateKeyTemplate,
    CK_ULONG ulPrivateKeyAttributeCount,
    CK_OBJECT_HANDLE_PTR phPublicKey,
    CK_OBJECT_HANDLE_PTR phPrivateKey));
_CK_DECLARE_FUNCTION(C_SKASign, (
    CK_SESSION_HANDLE hSession,
    CK_MECHANISM_PTR pMechanism,
    CK_OBJECT_HANDLE hSkaKey,
    CK_BYTE_PTR pApprovalToken, CK_ULONG ulApprovalTokenLen,
    CK_SKA_APPROVAL_PTR pApprovals, CK_ULONG ulApprovalCount,
    CK_BYTE_PTR pSignature, CK_ULONG_PTR pulSignatureLen, 
    CK_BYTE_PTR pPublicKey, CK_ULONG_PTR pulPublicKeyLen));
_CK_DECLARE_FUNCTION(C_SKADecrypt, (
    CK_SESSION_HANDLE hSession,
    CK_MECHANISM_PTR pMechanism,
    CK_OBJECT_HANDLE hSkaKey,
    CK_BYTE_PTR pApprovalToken, CK_ULONG ulApprovalTokenLen,
    CK_SKA_APPROVAL_PTR pApprovals, CK_ULONG ulApprovalCount,
    CK_BYTE_PTR pData, CK_ULONG_PTR pulDataLen));
_CK_DECLARE_FUNCTION(C_SKAUnwrapKey, (
    CK_SESSION_HANDLE hSession,
    CK_MECHANISM_PTR pMechanism,
    CK_OBJECT_HANDLE hSkaKey,
    CK_BYTE_PTR pApprovalToken, CK_ULONG ulApprovalTokenLen,
    CK_SKA_APPROVAL_PTR pApprovals, CK_ULONG ulApprovalCount,
    CK_ATTRIBUTE_PTR pTemplate, CK_ULONG ulAttributeCount,
    CK_OBJECT_HANDLE_PTR phKey));
_CK_DECLARE_FUNCTION(C_SKABlock, (
    CK_SESSION_HANDLE hSession,
    CK_OBJECT_HANDLE_PTR hSkaKey,
    CK_BYTE_PTR pApprovalToken, CK_ULONG ulApprovalTokenLen,
    CK_SKA_APPROVAL_PTR pApprovals, CK_ULONG ulApprovalCount));
_CK_DECLARE_FUNCTION(C_SKAUnblock, (
    CK_SESSION_HANDLE hSession,
    CK_OBJECT_HANDLE_PTR hSkaKey,
    CK_BYTE_PTR pApprovalToken, CK_ULONG ulApprovalTokenLen,
    CK_SKA_APPROVAL_PTR pApprovals, CK_ULONG ulApprovalCount));
_CK_DECLARE_FUNCTION(C_SKAModify, (
    CK_SESSION_HANDLE hSession,
    CK_OBJECT_HANDLE_PTR hSkaKey,
    CK_BYTE_PTR pApprovalToken, CK_ULONG ulApprovalTokenLen,
    CK_SKA_APPROVAL_PTR pApprovals, CK_ULONG ulApprovalCount));
_CK_DECLARE_FUNCTION(C_GetTimestamp, (
	CK_SESSION_HANDLE hSession,
	CK_SKA_OPERATION op,
	CK_MECHANISM_PTR pMechanism,
	CK_OBJECT_HANDLE hTimestampKey,
	CK_BYTE_PTR pPayload, CK_ULONG ulPayloadSize,
	CK_BYTE_PTR pTimestamp, CK_ULONG_PTR pulTimestampLen,
	CK_BYTE_PTR pTimestampSignatureData, CK_ULONG_PTR pulTimestampSignatureDataLen));
_CK_DECLARE_FUNCTION(C_CreateApprovalToken, (
    CK_SESSION_HANDLE hSession,
    CK_SKA_OPERATION op, 
    CK_OBJECT_HANDLE hSkaKey,
    CK_BYTE_PTR pPayload, CK_ULONG ulPayloadSize,
    CK_BYTE_PTR pTimestamp, CK_ULONG ulTimestampLen,
    CK_BYTE_PTR pTimestampSignature, CK_ULONG ulTimestampSignatureLen,
    CK_BYTE_PTR pToken, CK_ULONG_PTR pulTokenLen));
_CK_DECLARE_FUNCTION(C_SignApprovalToken, (
    CK_BYTE_PTR pKeyAlg, CK_ULONG ulKeyAlg,
    CK_BYTE_PTR pPrivateKey, CK_ULONG ulPrivateKeyLen,
    CK_SKA_APPROVER_PTR signerInfo,
    CK_BYTE_PTR pApprovalToken, CK_ULONG ulApprovalTokenLen,
    CK_SKA_APPROVAL_TYPE approvalType,
    CK_SKA_APPROVAL_PTR pSignedApproval));
_CK_DECLARE_FUNCTION(C_SerializePolicy, (
    CK_SKA_POLICY_PTR pPolicy,
    CK_BYTE_PTR pPolicyBuf, CK_ULONG_PTR pulPolicyBufLen));
_CK_DECLARE_FUNCTION(C_CreateModifyPayload, (
    CK_SKA_POLICY_PTR pUsePolicy, CK_SKA_POLICY_PTR pBlockPolicy,
    CK_SKA_POLICY_PTR pUnblockPolicy, CK_SKA_POLICY_PTR pModifyPolicy,
    CK_BYTE_PTR pModifyPayload, CK_ULONG_PTR pulModifyPayloadLen));
_CK_DECLARE_FUNCTION(C_CreateUnwrapPayload, (
    CK_BYTE_PTR pWrappedKey, CK_ULONG ulWrappedKeyLen,
    CK_ATTRIBUTE_PTR pTemplate, CK_ULONG ulAttributeCount,
    CK_BYTE_PTR pUnwrapPayload, CK_ULONG_PTR pulUnwrapPayloadLen));
_CK_DECLARE_FUNCTION(C_GetPersistentExternalObjectData, (
    CK_SESSION_HANDLE hSession,
    CK_OBJECT_HANDLE hObject,
    CK_BYTE_PTR pBuffer, CK_ULONG_PTR pulBufferLen));
_CK_DECLARE_FUNCTION(C_LoadPersistentExternalObject, (
	CK_SESSION_HANDLE hSession,
	CK_BYTE_PTR pBuffer, CK_ULONG ulBufferLen,
	CK_OBJECT_HANDLE_PTR phObject));
_CK_DECLARE_FUNCTION(C_RKSAttestKey, (
	CK_SESSION_HANDLE hSession,
	CK_MECHANISM_PTR pMechanism,
	CK_OBJECT_HANDLE hAttestationKey,
	CK_OBJECT_HANDLE hAttestedKey,
	CK_BYTE_PTR pXmlBuffer, CK_ULONG_PTR pulXmlBufferLen,
	CK_BYTE_PTR pSignature, CK_ULONG_PTR pulSignatureLen));
#undef _CK_DECLARE_FUNCTION

typedef struct CK_PRIMUS_FUNCTION_LIST {
    struct CK_VERSION version;
    CK_C_GetPrimusFunctionList C_GetPrimusFunctionList;
    CK_C_InitializeSpecificHSM C_InitializeSpecificHSM;
    CK_C_InitializeWithConfigFile C_InitializeWithConfigFile;
    CK_C_InitializeOpenSSL C_InitializeOpenSSL;
    CK_C_GetUserChallenge C_GetUserChallenge;
    CK_C_CryptoLogInit C_CryptoLogInit;
    CK_C_CryptoLogFetch C_CryptoLogFetch;
    CK_C_CryptoLogFinal C_CryptoLogFinal;
    CK_C_HsmStatus C_HsmStatus;
    CK_C_DeriveKeyPair C_DeriveKeyPair;
    CK_C_SKASign C_SKASign;
    CK_C_SKADecrypt C_SKADecrypt;
    CK_C_SKABlock C_SKABlock;
    CK_C_SKAUnblock C_SKAUnblock;
    CK_C_SKAModify C_SKAModify;
    CK_C_GetTimestamp C_GetTimestamp;
    CK_C_CreateApprovalToken C_CreateApprovalToken;
	CK_C_SignApprovalToken C_SignApprovalToken;
	CK_C_SerializePolicy C_SerializePolicy;
	CK_C_CreateModifyPayload C_CreateModifyPayload;
	CK_C_CreateUnwrapPayload C_CreateUnwrapPayload;
    CK_C_GetPersistentExternalObjectData C_GetPersistentExternalObjectData;
    CK_C_LoadPersistentExternalObject C_LoadPersistentExternalObject;
    CK_C_RKSAttestKey C_RKSAttestKey;
} CK_PRIMUS_FUNCTION_LIST;

#if defined(_WIN32) || defined(CRYPTOKI_FORCE_WIN32)
#pragma pack(pop, cryptoki)
#endif

#if defined(__cplusplus)
}
#endif

#endif /* _PRIMUS_PKCS11_H_ */